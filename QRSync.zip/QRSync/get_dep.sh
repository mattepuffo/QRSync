#!/bin/bash

for filename in lib/*; do
	echo $filename
	ldd $filename | grep "=> /" | awk '{print $3}' | xargs -I '{}' cp -v '{}' lib/
done